"""Trackmania baked cloth exporter for Blender.

The add-on writes a deterministic ``.tmcloth.json`` mesh-sequence interchange
file.  It intentionally does not pretend to write a GBX file: Item Studio
consumes this bounded, topology-stable representation and creates the native
Trackmania VertexTween item graph.
"""

from __future__ import annotations

import json
import math
import zipfile
from pathlib import Path
from typing import Any

import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    StringProperty,
)
from bpy.types import Operator, Panel, PropertyGroup


bl_info = {
    "name": "Trackmania Baked Cloth Exporter",
    "author": "TM Item Studio",
    "version": (0, 2, 1),
    "blender": (4, 0, 0),
    "location": "3D View > Sidebar > Trackmania",
    "description": "Author, preview and export topology-stable baked cloth frames for Trackmania Item Studio",
    "category": "Import-Export",
}


PREVIEW_SHAPE_KEY = "TMIS Preview"
_PREVIEW_RUNTIME: dict[str, Any] | None = None
_PROPERTY_GUARD = False


def _axis_index(axis: str) -> int:
    return {"X": 0, "Y": 1, "Z": 2}.get(axis, 0)


def _template_value(template: str, t: float) -> float:
    """Return the editable time-point value for one of the built-in motions."""
    tau = 2.0 * math.pi
    if template == "STILL":
        return 0.0
    if template == "GENTLE":
        return 0.55 + 0.45 * math.sin(tau * t)
    if template == "STRONG_GUST":
        gust = math.exp(-((t - 0.32) / 0.12) ** 2)
        return 0.55 + 0.25 * math.sin(tau * t) + 0.8 * gust
    if template == "FLUTTER":
        return 0.68 + 0.32 * math.sin(tau * 3.0 * t + 0.3)
    if template == "CROSSWIND":
        return 0.75 + 0.20 * math.sin(tau * t) + 0.12 * math.sin(tau * 5.0 * t)
    return 1.0


def _ensure_frame_points(settings: Any) -> None:
    target = max(2, min(512, int(settings.frame_count)))
    was_empty = len(settings.points) == 0
    while len(settings.points) < target:
        point = settings.points.add()
        point.value = 1.0
    while len(settings.points) > target:
        settings.points.remove(len(settings.points) - 1)
    # A freshly created scene should show the selected motion template straight
    # away.  Do this only for the first lazy initialization so changing the
    # frame count never overwrites points that the author already edited.
    if was_empty and settings.points:
        template = str(getattr(settings, "template", "GENTLE"))
        count = len(settings.points)
        for index, point in enumerate(settings.points):
            point.value = _template_value(template, index / max(1, count - 1))


def _apply_template_values(settings: Any) -> None:
    _ensure_frame_points(settings)
    count = len(settings.points)
    for index, point in enumerate(settings.points):
        t = index / max(1, count - 1)
        point.value = _template_value(settings.template, t)


def _active_preview_object(scene: bpy.types.Scene, settings: Any) -> bpy.types.Object | None:
    name = str(settings.preview_object)
    obj = scene.objects.get(name) if name else None
    return obj if obj is not None and obj.type == "MESH" else None


def _sample_point_value(settings: Any, t: float) -> float:
    _ensure_frame_points(settings)
    if not settings.points:
        return 0.0
    x = max(0.0, min(1.0, float(t))) * (len(settings.points) - 1)
    lo = int(math.floor(x))
    hi = min(len(settings.points) - 1, lo + 1)
    blend = x - lo
    return float(settings.points[lo].value) * (1.0 - blend) + float(settings.points[hi].value) * blend


def _preview_t_from_scene(scene: bpy.types.Scene, settings: Any) -> float:
    start = float(settings.frame_start)
    end = float(settings.frame_end)
    if end <= start:
        return 0.0
    return max(0.0, min(1.0, (float(scene.frame_current) - start) / (end - start)))


def _preview_t_from_point(settings: Any) -> float:
    return (max(1, min(int(settings.frame_count), int(settings.preview_frame))) - 1) / max(1, int(settings.frame_count) - 1)


def _group_indices(obj: bpy.types.Object, group_name: str) -> set[int]:
    if not group_name:
        return set()
    group = obj.vertex_groups.get(group_name)
    if group is None:
        return set()
    result: set[int] = set()
    for vertex in obj.data.vertices:
        try:
            group.weight(vertex.index)
        except RuntimeError:
            continue
        result.add(vertex.index)
    return result


def _ensure_preview_shape_key(obj: bpy.types.Object):
    if obj.type != "MESH":
        return None
    shape_keys = obj.data.shape_keys
    # Blender uses the first shape key as the basis.  Supplying our preview
    # name to the first call would make the preview itself the basis and leave
    # no deformable key, so create an explicit Basis first on plain meshes.
    if shape_keys is None:
        obj.shape_key_add(name="Basis")
        shape_keys = obj.data.shape_keys
    key = shape_keys.key_blocks.get(PREVIEW_SHAPE_KEY) if shape_keys else None
    if key is None:
        key = obj.shape_key_add(name=PREVIEW_SHAPE_KEY)
    return key


def _preview_positions(obj: bpy.types.Object, settings: Any, t: float) -> list[Any]:
    key = _ensure_preview_shape_key(obj)
    if key is None:
        return []
    shape_keys = obj.data.shape_keys
    basis = shape_keys.key_blocks.get("Basis") if shape_keys else None
    if basis is None:
        return [vertex.co.copy() for vertex in obj.data.vertices]
    source = [point.co.copy() for point in basis.data]
    if not source:
        return source

    horizontal = _axis_index(settings.horizontal_axis)
    vertical = _axis_index(settings.vertical_axis)
    displacement_axis = _axis_index(settings.displacement_axis)
    if horizontal == vertical:
        vertical = 2 if horizontal != 2 else 1
    if displacement_axis in {horizontal, vertical}:
        displacement_axis = ({0, 1, 2} - {horizontal, vertical}).pop()

    h_values = [float(co[horizontal]) for co in source]
    v_values = [float(co[vertical]) for co in source]
    h_min, h_max = min(h_values), max(h_values)
    v_min, v_max = min(v_values), max(v_values)
    h_span = max(1e-7, h_max - h_min)
    v_span = max(1e-7, v_max - v_min)
    cloth_indices = _group_indices(obj, settings.cloth_group)
    anchor_indices = _group_indices(obj, settings.anchor_group)
    anchor_u = 0.0
    if anchor_indices:
        anchor_u = sum((h_values[index] - h_min) / h_span for index in anchor_indices) / len(anchor_indices)
    else:
        anchor_u = 0.0
    max_distance = max(abs(((h - h_min) / h_span) - anchor_u) for h in h_values) or 1.0
    point_strength = _sample_point_value(settings, t)
    phase = math.radians(float(settings.phase_degrees))
    tau = 2.0 * math.pi
    output = []
    for index, co in enumerate(source):
        if cloth_indices and index not in cloth_indices:
            output.append(co)
            continue
        if index in anchor_indices:
            output.append(co)
            continue
        u = (float(co[horizontal]) - h_min) / h_span
        v = (float(co[vertical]) - v_min) / v_span
        edge = max(0.0, min(1.0, abs(u - anchor_u) / max_distance))
        edge = edge ** max(0.05, float(settings.edge_falloff))
        vertical_factor = 0.25 + 0.75 * max(0.0, min(1.0, v))
        travel_phase = tau * float(settings.travel_cycles) * t
        spatial = math.sin(tau * float(settings.frequency) * u + phase + travel_phase)
        secondary = math.sin(tau * float(settings.frequency) * 0.5 * u - phase * 0.5 + travel_phase * 1.7)
        displacement = (
            float(settings.amplitude)
            * point_strength
            * edge
            * vertical_factor
            * (0.78 * spatial + 0.22 * secondary)
        )
        co[displacement_axis] += displacement
        output.append(co)
    return output


def _update_preview_shape(obj: bpy.types.Object, settings: Any, t: float | None = None) -> None:
    key = _ensure_preview_shape_key(obj)
    if key is None:
        return
    if t is None:
        t = _preview_t_from_point(settings)
    positions = _preview_positions(obj, settings, t)
    for point, co in zip(key.data, positions):
        point.co = co
    key.value = 1.0 if bool(settings.preview_enabled) else 0.0
    obj.data.update()


def _point_update(self: Any, context: bpy.types.Context) -> None:
    if context and context.scene:
        settings = context.scene.tmis_cloth_settings
        obj = _active_preview_object(context.scene, settings)
        if obj and settings.preview_enabled:
            _update_preview_shape(obj, settings)


def _frame_count_update(self: Any, context: bpy.types.Context) -> None:
    global _PROPERTY_GUARD
    _ensure_frame_points(self)
    target = max(1, min(int(self.frame_count), 512))
    if int(self.preview_frame) > target:
        _PROPERTY_GUARD = True
        try:
            self.preview_frame = target
        finally:
            _PROPERTY_GUARD = False
    if context and context.scene:
        obj = _active_preview_object(context.scene, self)
        if obj and self.preview_enabled:
            _update_preview_shape(obj, self)


def _template_update(self: Any, context: bpy.types.Context) -> None:
    _apply_template_values(self)
    if context and context.scene:
        obj = _active_preview_object(context.scene, self)
        if obj and self.preview_enabled:
            _update_preview_shape(obj, self)


def _preview_enabled_update(self: Any, context: bpy.types.Context) -> None:
    if not context or not context.scene:
        return
    obj = context.object if context.object and context.object.type == "MESH" else _active_preview_object(context.scene, self)
    if obj is None:
        self.preview_enabled = False
        return
    self.preview_object = obj.name
    _ensure_frame_points(self)
    _update_preview_shape(obj, self)


def _preview_frame_update(self: Any, context: bpy.types.Context) -> None:
    global _PROPERTY_GUARD
    if _PROPERTY_GUARD or not context or not context.scene:
        return
    obj = _active_preview_object(context.scene, self)
    if obj is None:
        return
    start = int(self.frame_start)
    end = int(self.frame_end)
    if end > start:
        _PROPERTY_GUARD = True
        try:
            scene_frame = round(start + _preview_t_from_point(self) * (end - start))
            context.scene.frame_set(scene_frame)
        finally:
            _PROPERTY_GUARD = False
    if self.preview_enabled:
        _update_preview_shape(obj, self)


def _frame_change_handler(scene: bpy.types.Scene) -> None:
    global _PROPERTY_GUARD
    settings = getattr(scene, "tmis_cloth_settings", None)
    if settings is None or not settings.preview_enabled:
        return
    obj = _active_preview_object(scene, settings)
    if obj is None:
        return
    t = _preview_t_from_scene(scene, settings)
    _PROPERTY_GUARD = True
    try:
        settings.preview_frame = int(round(t * (int(settings.frame_count) - 1))) + 1
    finally:
        _PROPERTY_GUARD = False
    _update_preview_shape(obj, settings, t)


def _finite(value: float) -> bool:
    return math.isfinite(float(value))


def _vec(value: Any) -> list[float]:
    return [float(value[0]), float(value[1]), float(value[2])]


def _uv(value: Any) -> list[float]:
    return [float(value[0]), float(value[1])]


def _same(a: Any, b: Any, tolerance: float = 1e-6) -> bool:
    if len(a) != len(b):
        return False
    return all(abs(float(x) - float(y)) <= tolerance for x, y in zip(a, b))


def validate_topology(reference: dict[str, Any], candidate: dict[str, Any],
                      frame_label: str = "sample") -> None:
    """Raise a useful error when a sampled mesh cannot share one index stream.

    Cloth baking is a mesh *sequence*: every frame must have the same loop
    count, triangle order, source vertex mapping and UVs.  Keeping this check
    independent of Blender makes the contract easy to audit in downstream
    tooling as well.
    """
    if len(candidate["positions"]) != len(reference["positions"]):
        raise ValueError(f"Topology changed at {frame_label}: loop count differs")
    if candidate["indices"] != reference["indices"]:
        raise ValueError(f"Topology changed at {frame_label}: index layout differs")
    if candidate["vertex_indices"] != reference["vertex_indices"]:
        raise ValueError(f"Topology changed at {frame_label}: vertex mapping differs")
    if any(not _same(a, b) for a, b in zip(candidate["uv0"], reference["uv0"])):
        raise ValueError(f"UV layout changed at {frame_label}")


def _evaluated_mesh(obj: bpy.types.Object, depsgraph: bpy.types.Depsgraph):
    evaluated = obj.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
    mesh.calc_loop_triangles()
    # Blender 4.1+ calculates split normals on evaluated meshes during
    # dependency-graph evaluation and removed the old explicit calc_normals
    # methods in some builds. Keep the calls for older releases, but treat
    # their absence as the already-valid evaluated-normal state.
    if hasattr(mesh, "calc_normals_split"):
        mesh.calc_normals_split()
    elif hasattr(mesh, "calc_normals"):
        mesh.calc_normals()
    return evaluated, mesh


def _extract_mesh(mesh: bpy.types.Mesh, uv_name: str = "") -> dict[str, Any]:
    loops = mesh.loops
    triangles = mesh.loop_triangles
    uv_layer = mesh.uv_layers.get(uv_name) if uv_name else mesh.uv_layers.active
    # Loop-expanded vertices preserve UV seams and split normals. This is the
    # safest interchange form for the later GBX writer: each corner has one
    # position, normal and UV, and triangle indices are stable across frames.
    positions: list[list[float]] = []
    normals: list[list[float]] = []
    uvs: list[list[float]] = []
    for loop in loops:
        p = mesh.vertices[loop.vertex_index].co
        n = getattr(loop, "normal", mesh.vertices[loop.vertex_index].normal)
        positions.append(_vec(p))
        normals.append(_vec(n))
        uvs.append(_uv(uv_layer.data[loop.index].uv) if uv_layer else [0.0, 0.0])
    indices = [int(loop_index) for tri in triangles for loop_index in tri.loops]
    if len(indices) % 3:
        raise ValueError("Evaluated mesh has a non-triangular loop layout")
    if any(not _finite(component) for row in positions + normals + uvs for component in row):
        raise ValueError("Mesh contains a non-finite position, normal or UV")
    return {
        "positions": positions,
        "normals": normals,
        "uv0": uvs,
        "indices": indices,
        "vertex_indices": [int(loop.vertex_index) for loop in loops],
    }


def _anchor_indices(obj: bpy.types.Object, mesh: bpy.types.Mesh, group_name: str) -> list[int]:
    if not group_name:
        return []
    group = obj.vertex_groups.get(group_name)
    if group is None:
        raise ValueError(f"Anchor vertex group '{group_name}' was not found")
    # VertexGroup membership lookup is deliberately used instead of reading
    # weights from evaluated mesh: the source object defines the attachment.
    result: list[int] = []
    for vertex in mesh.vertices:
        try:
            group.weight(vertex.index)
            result.append(vertex.index)
        except RuntimeError:
            pass
    if not result:
        raise ValueError(f"Anchor vertex group '{group_name}' has no vertices")
    return result


def export_mesh_sequence(
    context: bpy.types.Context,
    obj: bpy.types.Object,
    frame_count: int,
    frame_start: float,
    frame_end: float,
    anchor_group: str = "",
    pin_anchor: bool = True,
    apply_modifiers: bool = True,
    period_seconds: float = 12.0,
) -> dict[str, Any]:
    if obj.type != "MESH":
        raise ValueError("Select a mesh object")
    if frame_count < 2 or frame_count > 512:
        raise ValueError("Frame count must be between 2 and 512")
    if not (_finite(frame_start) and _finite(frame_end)) or frame_end <= frame_start:
        raise ValueError("Frame range must be finite and end after start")
    if not _finite(period_seconds) or period_seconds < 0.25 or period_seconds > 60.0:
        raise ValueError("Playback period must be between 0.25 and 60 seconds")

    scene = context.scene
    original_frame = scene.frame_current
    original_subframe = scene.frame_subframe
    depsgraph = context.evaluated_depsgraph_get()
    samples = [frame_start + (frame_end - frame_start) * i / (frame_count - 1) for i in range(frame_count)]
    frames: list[dict[str, Any]] = []
    base: dict[str, Any] | None = None
    anchor_vertex_indices: list[int] = []
    rest_anchor: list[float] | None = None
    try:
        for sample in samples:
            scene.frame_set(int(math.floor(sample)), subframe=sample - math.floor(sample))
            # When the author enables the Trackmania preview, export exactly
            # the authored point-grid motion.  With the preview disabled the
            # exporter retains its original behaviour and samples Blender's
            # own baked animation/modifiers.
            preview_settings = getattr(scene, "tmis_cloth_settings", None)
            if (
                preview_settings is not None
                and bool(preview_settings.preview_enabled)
                and str(preview_settings.preview_object) == obj.name
            ):
                preview_t = (sample - frame_start) / (frame_end - frame_start)
                _update_preview_shape(obj, preview_settings, preview_t)
            evaluated, mesh = _evaluated_mesh(obj, depsgraph)
            try:
                extracted = _extract_mesh(mesh, obj.data.uv_layers.active.name if obj.data.uv_layers.active else "")
                if base is None:
                    base = extracted
                    anchor_vertex_indices = _anchor_indices(obj, mesh, anchor_group)
                    if anchor_vertex_indices:
                        rest_anchor = [
                            sum(extracted["positions"][i][axis] for i in range(len(extracted["positions"])) if extracted["vertex_indices"][i] in anchor_vertex_indices)
                            / sum(1 for i in range(len(extracted["positions"])) if extracted["vertex_indices"][i] in anchor_vertex_indices)
                            for axis in range(3)
                        ]
                else:
                    validate_topology(base, extracted, f"sampled frame {sample:g}")
                positions = [row[:] for row in extracted["positions"]]
                if pin_anchor and rest_anchor and anchor_vertex_indices:
                    current_rows = [
                        row for i, row in enumerate(positions) if extracted["vertex_indices"][i] in anchor_vertex_indices
                    ]
                    count = len(current_rows)
                    current_anchor = [sum(row[axis] for row in current_rows) / count for axis in range(3)]
                    delta = [rest_anchor[axis] - current_anchor[axis] for axis in range(3)]
                    positions = [[row[axis] + delta[axis] for axis in range(3)] for row in positions]
                frames.append({"positions": positions, "normals": extracted["normals"]})
            finally:
                evaluated.to_mesh_clear()
    finally:
        scene.frame_set(original_frame, subframe=original_subframe)

    if base is None:
        raise ValueError("No mesh frames were sampled")
    anchor = rest_anchor or [0.0, 0.0, 0.0]
    return {
        "formatVersion": 1,
        "exporter": "Trackmania Baked Cloth Exporter",
        "objectName": obj.name,
        "coordinates": "object-local evaluated mesh coordinates",
        "frameCount": frame_count,
        "periodSeconds": float(period_seconds),
        "sampleFrames": samples,
        "vertexCount": len(base["positions"]),
        "triangleCount": len(base["indices"]) // 3,
        "indices": base["indices"],
        "vertexIndices": base["vertex_indices"],
        "uv0": base["uv0"],
        "anchor": {"vertexGroup": anchor_group, "position": anchor, "pinned": bool(pin_anchor)},
        "frames": frames,
        "source": {
            "applyModifiers": bool(apply_modifiers),
            "topology": "loop-expanded; UV seams and split normals preserved",
            "lods": "one exported sequence; Item Studio can replicate it to the supported LOD set",
        },
        "validation": {
            "topologyChecked": True,
            "checkedFrameCount": frame_count,
            "uvLayoutChecked": True,
        },
    }


class TMIS_FramePoint(PropertyGroup):
    value: FloatProperty(name="Strength", default=1.0, min=-2.0, max=2.0, update=_point_update)


class TMIS_ClothSettings(PropertyGroup):
    frame_count: IntProperty(name="Frame count", default=86, min=2, max=512, update=_frame_count_update)
    frame_start: IntProperty(name="Start frame", default=1)
    frame_end: IntProperty(name="End frame", default=86)
    anchor_group: StringProperty(name="Anchor vertex group", default="")
    cloth_group: StringProperty(name="Cloth vertex group", default="")
    pin_anchor: BoolProperty(name="Pin anchor", default=True)
    apply_modifiers: BoolProperty(name="Evaluate modifiers", default=True)
    period_seconds: FloatProperty(name="Trackmania period (s)", default=12.0, min=0.25, max=60.0)
    output_path: StringProperty(name="Output", subtype="FILE_PATH", default="")
    package_zip: BoolProperty(name="Also create ZIP", default=True)

    template: EnumProperty(
        name="Motion template",
        items=(
            ("GENTLE", "Gentle wave", "Low-amplitude continuous wind"),
            ("STRONG_GUST", "Strong gust", "A broad gust with a stronger pulse"),
            ("FLUTTER", "Flutter", "Faster repeated flutter"),
            ("CROSSWIND", "Crosswind", "Layered wind with a short secondary ripple"),
            ("STILL", "Still", "Zero displacement; useful as a rest pose"),
        ),
        default="GENTLE",
        update=_template_update,
    )
    amplitude: FloatProperty(name="Amplitude", default=0.45, min=0.0, max=10.0)
    frequency: FloatProperty(name="Spatial frequency", default=1.25, min=0.05, max=12.0)
    travel_cycles: FloatProperty(name="Travel cycles", default=1.0, min=-12.0, max=12.0)
    phase_degrees: FloatProperty(name="Phase (degrees)", default=0.0, min=-360.0, max=360.0)
    edge_falloff: FloatProperty(name="Edge falloff", default=1.35, min=0.05, max=8.0)
    horizontal_axis: EnumProperty(
        name="Width axis",
        items=(("X", "X", "Use local X as the flag width"), ("Y", "Y", "Use local Y as the flag width"), ("Z", "Z", "Use local Z as the flag width")),
        default="X",
    )
    vertical_axis: EnumProperty(
        name="Height axis",
        items=(("X", "X", "Use local X as the flag height"), ("Y", "Y", "Use local Y as the flag height"), ("Z", "Z", "Use local Z as the flag height")),
        default="Z",
    )
    displacement_axis: EnumProperty(
        name="Wind axis",
        items=(("X", "X", "Displace along local X"), ("Y", "Y", "Displace along local Y"), ("Z", "Z", "Displace along local Z")),
        default="Y",
    )
    points: CollectionProperty(type=TMIS_FramePoint)
    preview_frame: IntProperty(name="Preview point", default=1, min=1, max=512, update=_preview_frame_update)
    preview_enabled: BoolProperty(name="Live viewport preview", default=False, update=_preview_enabled_update)
    preview_object: StringProperty(name="Preview object", default="")
    preview_playing: BoolProperty(name="Playing", default=False)


def _stop_preview() -> None:
    global _PREVIEW_RUNTIME
    runtime = _PREVIEW_RUNTIME
    if runtime is None:
        return
    try:
        runtime["window_manager"].event_timer_remove(runtime["timer"])
    except Exception:
        pass
    try:
        runtime["settings"].preview_playing = False
    except Exception:
        pass
    _PREVIEW_RUNTIME = None


class TMIS_OT_apply_template(Operator):
    bl_idname = "tmis.apply_motion_template"
    bl_label = "Apply motion template"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.tmis_cloth_settings
        _apply_template_values(settings)
        obj = _active_preview_object(context.scene, settings)
        if obj and settings.preview_enabled:
            _update_preview_shape(obj, settings)
        return {"FINISHED"}


class TMIS_OT_enable_preview(Operator):
    bl_idname = "tmis.enable_viewport_preview"
    bl_label = "Preview on selected mesh"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.object
        if obj is None or obj.type != "MESH":
            self.report({"ERROR"}, "Select a mesh object first")
            return {"CANCELLED"}
        settings = context.scene.tmis_cloth_settings
        settings.preview_object = obj.name
        _ensure_frame_points(settings)
        settings.preview_enabled = True
        _update_preview_shape(obj, settings)
        return {"FINISHED"}


class TMIS_OT_disable_preview(Operator):
    bl_idname = "tmis.disable_viewport_preview"
    bl_label = "Disable viewport preview"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.tmis_cloth_settings
        settings.preview_enabled = False
        obj = _active_preview_object(context.scene, settings)
        if obj:
            _update_preview_shape(obj, settings)
        _stop_preview()
        return {"FINISHED"}


class TMIS_OT_play_preview(Operator):
    bl_idname = "tmis.play_viewport_preview"
    bl_label = "Play viewport preview"

    def execute(self, context):
        global _PREVIEW_RUNTIME
        if _PREVIEW_RUNTIME is not None:
            _stop_preview()
            return {"FINISHED"}
        obj = context.object
        if obj is None or obj.type != "MESH":
            self.report({"ERROR"}, "Select a mesh object first")
            return {"CANCELLED"}
        settings = context.scene.tmis_cloth_settings
        settings.preview_object = obj.name
        settings.preview_enabled = True
        _ensure_frame_points(settings)
        _update_preview_shape(obj, settings)
        settings.preview_playing = True
        timer = context.window_manager.event_timer_add(1.0 / 30.0, window=context.window)
        _PREVIEW_RUNTIME = {
            "operator": self,
            "timer": timer,
            "window_manager": context.window_manager,
            "settings": settings,
        }
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        global _PREVIEW_RUNTIME
        if _PREVIEW_RUNTIME is None or _PREVIEW_RUNTIME.get("operator") is not self:
            return {"FINISHED"}
        if event.type == "TIMER":
            settings = _PREVIEW_RUNTIME["settings"]
            next_frame = int(settings.preview_frame) + 1
            if next_frame > int(settings.frame_count):
                next_frame = 1
            settings.preview_frame = next_frame
            if context.area:
                context.area.tag_redraw()
            return {"RUNNING_MODAL"}
        if event.type in {"ESC", "RIGHTMOUSE"}:
            _stop_preview()
            return {"CANCELLED"}
        return {"PASS_THROUGH"}


class TMIS_OT_export_cloth(Operator):
    bl_idname = "tmis.export_baked_cloth"
    bl_label = "Export baked cloth sequence"
    bl_options = {"REGISTER"}

    def execute(self, context: bpy.types.Context):
        settings = context.scene.tmis_cloth_settings
        obj = context.active_object
        if obj is None:
            self.report({"ERROR"}, "Select a mesh object")
            return {"CANCELLED"}
        output = bpy.path.abspath(settings.output_path) if settings.output_path else ""
        if not output:
            self.report({"ERROR"}, "Choose an output path")
            return {"CANCELLED"}
        if output.lower().endswith(".zip"):
            output = output[:-4]
        if not output.lower().endswith(".tmcloth.json"):
            output += ".tmcloth.json"
        try:
            payload = export_mesh_sequence(
                context, obj, settings.frame_count, settings.frame_start, settings.frame_end,
                settings.anchor_group, settings.pin_anchor, settings.apply_modifiers, settings.period_seconds,
            )
            Path(output).parent.mkdir(parents=True, exist_ok=True)
            raw = json.dumps(payload, indent=2, separators=(",", ": ")) + "\n"
            Path(output).write_text(raw, encoding="utf-8", newline="\n")
            if settings.package_zip:
                zip_path = str(Path(output).with_suffix("")) + ".zip"
                readme_path = Path(__file__).with_name("README.md")
                readme = readme_path.read_text(encoding="utf-8") if readme_path.exists() else (
                    "# Trackmania baked cloth sequence\n\n"
                    "This is a topology-stable `.tmcloth.json` interchange file; it is not a `.Item.Gbx`.\n"
                )
                # ZipFile otherwise stamps entries with wall-clock time.  A
                # fixed DOS timestamp keeps repeated exports reproducible.
                def _write_fixed(archive: zipfile.ZipFile, name: str, data: str) -> None:
                    info = zipfile.ZipInfo(name, date_time=(2020, 1, 1, 0, 0, 0))
                    info.compress_type = zipfile.ZIP_DEFLATED
                    info.external_attr = 0o644 << 16
                    archive.writestr(info, data.encode("utf-8"))

                with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
                    _write_fixed(archive, Path(output).name, raw)
                    _write_fixed(archive, "README.md", readme)
                self.report({"INFO"}, f"Exported {Path(output).name} and {Path(zip_path).name}")
            else:
                self.report({"INFO"}, f"Exported {Path(output).name}")
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        return {"FINISHED"}


class TMIS_PT_cloth_export(Panel):
    bl_label = "Trackmania baked cloth"
    bl_idname = "TMIS_PT_cloth_export"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "object"

    def draw(self, context: bpy.types.Context):
        layout = self.layout
        settings = context.scene.tmis_cloth_settings
        col = layout.column(align=True)
        col.prop(settings, "frame_count")
        row = col.row(align=True)
        row.prop(settings, "frame_start")
        row.prop(settings, "frame_end")
        col.prop_search(settings, "anchor_group", context.object, "vertex_groups")
        col.prop(settings, "pin_anchor")
        col.prop(settings, "apply_modifiers")
        col.prop(settings, "period_seconds")
        col.prop(settings, "output_path")
        col.prop(settings, "package_zip")
        col.operator(TMIS_OT_export_cloth.bl_idname, icon="EXPORT")
        layout.label(text="Output is a topology-stable .tmcloth.json interchange file.")


class TMIS_PT_cloth_view3d(Panel):
    """Authoring and preview panel in the 3D View sidebar (N)."""

    bl_label = "Waving cloth"
    bl_idname = "TMIS_PT_cloth_view3d"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Trackmania"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.tmis_cloth_settings
        obj = context.object
        if obj is None or obj.type != "MESH":
            layout.label(text="Select a mesh object to author a flag.", icon="INFO")
            return

        _ensure_frame_points(settings)

        header = layout.box()
        header.label(text=f"Selected mesh: {obj.name}", icon="MESH_DATA")
        header.prop(settings, "template", text="Motion template")
        header.operator("tmis.apply_motion_template", icon="FILE_REFRESH")

        preview = layout.box()
        preview.label(text="Viewport preview", icon="PLAY")
        preview.prop(settings, "preview_enabled", text="Live preview")
        row = preview.row(align=True)
        play_label = "Stop preview" if _PREVIEW_RUNTIME is not None else "Play preview"
        row.operator("tmis.play_viewport_preview", text=play_label, icon="PAUSE" if _PREVIEW_RUNTIME is not None else "PLAY")
        row.operator("tmis.enable_viewport_preview", text="Apply", icon="CHECKMARK")
        row.operator("tmis.disable_viewport_preview", text="Clear", icon="X")
        preview.prop(settings, "preview_frame", slider=True)
        preview.label(text=f"Point {settings.preview_frame} / {settings.frame_count}")

        motion = layout.box()
        motion.label(text="Motion controls", icon="MOD_WAVE")
        motion.prop(settings, "amplitude", slider=True)
        motion.prop(settings, "frequency", slider=True)
        motion.prop(settings, "travel_cycles", slider=True)
        motion.prop(settings, "phase_degrees", slider=True)
        motion.prop(settings, "edge_falloff", slider=True)
        axes = motion.column(align=True)
        axes.prop(settings, "horizontal_axis", text="Width")
        axes.prop(settings, "vertical_axis", text="Height")
        axes.prop(settings, "displacement_axis", text="Wind")
        motion.prop_search(settings, "cloth_group", obj, "vertex_groups")
        motion.prop_search(settings, "anchor_group", obj, "vertex_groups")
        motion.prop(settings, "pin_anchor")

        points = layout.box()
        points.label(text=f"Editable frame-point grid ({len(settings.points)} points)", icon="SEQ_SEQUENCER")
        points.label(text="Each slider is a time sample used by the preview/export.")
        grid = points.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False)
        for index, point in enumerate(settings.points):
            grid.prop(point, "value", text=f"{index + 1:02d}", slider=True)

        export = layout.box()
        export.label(text="Export", icon="EXPORT")
        export.prop(settings, "frame_count")
        row = export.row(align=True)
        row.prop(settings, "frame_start")
        row.prop(settings, "frame_end")
        export.prop(settings, "period_seconds")
        export.prop(settings, "output_path")
        export.prop(settings, "package_zip")
        if settings.preview_enabled:
            export.label(text="Live preview is the exported animation.", icon="INFO")
        export.operator("tmis.export_baked_cloth", icon="EXPORT")


CLASSES = (
    TMIS_FramePoint,
    TMIS_ClothSettings,
    TMIS_OT_apply_template,
    TMIS_OT_enable_preview,
    TMIS_OT_disable_preview,
    TMIS_OT_play_preview,
    TMIS_OT_export_cloth,
    TMIS_PT_cloth_export,
    TMIS_PT_cloth_view3d,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.tmis_cloth_settings = bpy.props.PointerProperty(type=TMIS_ClothSettings)
    if _frame_change_handler not in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.append(_frame_change_handler)


def unregister():
    _stop_preview()
    if _frame_change_handler in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.remove(_frame_change_handler)
    if hasattr(bpy.types.Scene, "tmis_cloth_settings"):
        del bpy.types.Scene.tmis_cloth_settings
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
