# Trackmania Baked Cloth Exporter

This Blender 4.0+ add-on exports a simulated cloth object as a deterministic
mesh-sequence JSON file for TM Item Studio. It is intended for flags, banners,
and other baked cloth that must play without a runtime cloth simulation.

## Install

In Blender choose **Edit > Preferences > Add-ons > Install…**, select
`trackmania_baked_cloth.zip`, enable **Trackmania Baked Cloth Exporter**, and
select a mesh object. Move the mouse over the 3D View and press **N**. Open
the **Trackmania** tab and choose **Waving cloth**.

The N-panel supports the complete authoring loop:

- choose **Gentle wave**, **Strong gust**, **Flutter**, **Crosswind** or
  **Still**;
- edit the 86 time samples in the frame-point grid (the grid follows
  `Frame count`);
- tune amplitude, spatial frequency, travel, phase and the local width,
  height and wind axes;
- optionally select a cloth vertex group and an anchor vertex group;
- enable **Live preview** or press **Play preview** to deform the selected mesh
  in the Blender viewport.

The compact **Properties > Object > Trackmania baked cloth** panel remains
available as an export-only view. If the N panel is hidden, move the mouse over
the 3D View and press `N`, then click the **Trackmania** tab.

## Export

Set the simulation range and output path, then click **Export baked cloth
sequence**. The default is 86 samples (frames 1–86), matching the Trackmania
cloth playback budget. The exporter evaluates each sample, expands loops so UV
seams and split normals remain explicit, and checks that all 86 frames have an
identical loop count, triangle/index order, source-vertex mapping, and UV0.
Any mismatch stops the export with the offending sample in the error message.

When **Live preview** is enabled, the export contains the same point-grid
motion shown in the viewport. With the preview disabled, the exporter samples
the selected object's own baked Blender animation and modifiers as before.

Set **Trackmania period (s)** to the desired playback period (0.25–60 seconds).
This value is written to the sequence metadata and will be copied into the
native `PeriodSc`/`PeriodScMax` fields by the Item Studio importer.

An optional vertex group pins an attachment edge to its rest-frame centroid.
The JSON contains positions and normals for every frame plus one shared index
and UV stream. Coordinates are object-local evaluated Blender coordinates;
apply the same object transform when importing into Item Studio.

The optional ZIP contains the JSON and this README. ZIP entry timestamps are
fixed so rebuilding the same input produces byte-for-byte identical output.
The JSON is an interchange format (`.tmcloth.json`), not a native
`.Item.Gbx`. In Item Studio, choose **Import Blender baked cloth sequence**;
the selected visual must have matching rest positions, UV0, triangle order and
winding. Item Studio then writes the sequence to the native 86-frame
`VertexTween` graph and replicates it to the five supported LOD visuals.

For a seamless loop, make the first and last samples identical. The importer
rejects an open endpoint instead of silently changing the animation. A topology
changing simulation (tearing, remeshing or a different triangulation) must be
fixed in Blender before export.

## JSON contract

`formatVersion` is currently `1`. `frameCount`, `vertexCount`, `triangleCount`,
`indices`, and `uv0` describe the shared topology. `frames` stores one
`positions` and `normals` array per sample. `validation.checkedFrameCount` and
`validation.topologyChecked` record that the full requested range was checked.

The add-on has no network or external dependencies and does not modify the
scene beyond temporarily changing the current frame while sampling (the
original frame and subframe are restored before returning).
